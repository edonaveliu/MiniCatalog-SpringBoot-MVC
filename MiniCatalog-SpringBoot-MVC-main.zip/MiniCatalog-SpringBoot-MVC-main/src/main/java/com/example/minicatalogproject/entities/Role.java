package com.example.minicatalogproject.entities;

public enum Role {
    USER,
    ADMIN
}
